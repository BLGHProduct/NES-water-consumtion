


function map_range(value, low1, high1, low2, high2) {
    return low2 + (high2 - low2) * (value - low1) / (high1 - low1);
  } 
const a=100-20;
let previousHeight = document.getElementById("curtain").style.height=map_range(a,0,100,0,145)+"%";

console.log(previousHeight);

//Input data section
var Temperature=30;  //Temperature of air
var humidity=20;    //Humidity in air
var Fan=1;         //Fan OFF/ON
var DtYester=100; //consumption yesterday
var DtAgo1=130;   //consumption 2d Ago
var DtMonth=1000; //consumption in last month


//Temperature Part
document.getElementById('temp').innerHTML=Temperature+"°C";

//Humidity Part
var root=document.querySelector(':root')
var rootStyles=getComputedStyle(root);
var p=rootStyles.getPropertyValue('--p');
root.style.setProperty('--p',humidity);
document.getElementById('humi').innerHTML=humidity+"%";

//Fan Part
 if(Fan==0){
    document.getElementById('fan').innerHTML="OFF";
 }
 else
 document.getElementById('fan').innerHTML="ON";

 
//Consumtion Part
document.getElementById('DataYest').innerHTML=DtYester+" Liter";
document.getElementById('DataAgo1').innerHTML=DtAgo1+" Liter";
document.getElementById('DataTotal').innerHTML=DtMonth+" Liter";

//   let direction = 10 
// function rep(){
//   let height = document.getElementById("curtain").style.height
//   if (height == "" || height == "0") height = "0%"

//   height = parseInt(height.split("%").join(''))
//   console.log(height)
//   if (height==100 || height == 0) {
//     direction = -direction
    
//   } 
//   // if (height == 0){
//   //   direction = 5
//   // }
//   height += direction
//   document.getElementById("curtain").style.height = height.toString() + "%"
//   setTimeout(()=>rep(), 250)
// }

// rep();